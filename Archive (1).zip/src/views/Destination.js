import { View, Text, Button } from 'react-native'

export default function Destination({ route, navigation }) {
  // const { pickupLocation } = route.params
  return (
    <View>
      <Text>Destination</Text>

      <Button title="Chalo!" />
    </View>
  )
}