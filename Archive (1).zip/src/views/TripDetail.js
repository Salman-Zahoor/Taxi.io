import { View, Text } from 'react-native'

export default function TripDetail({ navigation }) {
  return (
    <View>
      <Text>Trip Detail</Text>
    </View>
  )
}